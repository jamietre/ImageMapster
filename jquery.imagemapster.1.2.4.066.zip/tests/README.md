#### Tests for ImageMapster

5/15/2012

I am in the process of revising the test suite to use IQTest, a promise-aware testing framework I am developing. You can find the source on my github portal. This framework is designed around the assertions from [buster.js](http://busterjs.org/) and uses a terse syntax that allows creating one-line unit tests for asynchronous operations. 

The dev code (1.2.4.065) is mostly stable; it will become a release when I'm finished updating the tests.

The old tests (loaded from `test.html`) are no longer going to be supported. They are still here until I finish the update but should not be considered functional.

